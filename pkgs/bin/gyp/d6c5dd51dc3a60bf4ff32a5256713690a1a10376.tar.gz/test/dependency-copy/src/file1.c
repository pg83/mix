#include <stdio.h>

int main(void)
{
  printf("Hello from file1.c\n");
  return 0;
}
