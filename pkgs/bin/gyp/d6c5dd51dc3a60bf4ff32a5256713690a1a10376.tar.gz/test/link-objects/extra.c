#include <stdio.h>

void extra() {
  printf("PASS\n");
}
