#pragma once

struct rgba {
    double red;
    double green;
    double blue;
    double alpha;
};
