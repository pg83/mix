#pragma once

#include "terminal.h"

void notify_notify(
    const struct terminal *term, const char *title, const char *body);
